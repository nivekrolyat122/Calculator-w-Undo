﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Globalization;

namespace retryagain
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calc = new Calculator();
            bool sheet = true;

            CultureInfo ci = CultureInfo.InstalledUICulture;

            if (ci.Name == "en-US")
            {
                while (sheet)
                {
                    string input = Console.ReadLine();
                    Console.WriteLine("Total: " + calc.calculate(input) + " Running Total: " + calc.pushed);
                }
            }

            else if (ci.Name == "fr-FR")
            {
                while (sheet)
                {
                    string input = Console.ReadLine();
                    Console.WriteLine("Total: " + calc.calculate(input) + " total cumulé: " + calc.pushed);
                }
            }

            else if (ci.Name == "th.TH")
            {
                while (sheet)
                {
                    string input = Console.ReadLine();
                    Console.WriteLine("รวม: " + calc.calculate(input) + " กำลังทำงานทั้งหมด: " + calc.pushed);
                }
            }
        }
    }
}
