﻿using System;
using System.Collections.Generic;
using System.Text;

namespace retryagain
{
    public class Calculator
    {
        public float pushed;

        Stack<float> st = new Stack<float>(); 
        public float total;

        public string calculate(string input)
        {
            string[] separate = input.Split();

            if (separate[0] == "UNDO")
            {
                return Undo();
            }

            else if (separate[0] == "CLEAR")
            {
                return Clear();
            }

            else if (separate[0] == "EXIT")
            {
                return Exit();
            }

            else if (separate[1] == "+" | separate[1] == "-" | separate[1] == "*" | separate[1] == "/")
            {
                string operation = separate[1];
                float newFirst = float.Parse(separate[0]);
                float third = float.Parse(separate[2]);

                if (operation == "+")
                {
                    total = newFirst + third;
                    pushed += total;
                    st.Push(pushed);
                    return total.ToString();
                }

                else if (operation == "-")
                {
                    total = newFirst - third;
                    pushed += total;
                    st.Push(pushed);
                    return total.ToString() ;
                }

                else if (operation == "*")
                {
                    total = newFirst * third;
                    pushed += total;
                    st.Push(pushed);
                    return total.ToString();
                }

                else
                {
                    total = newFirst / third;
                    pushed += total;
                    st.Push(pushed);
                    return total.ToString();
                }
            }

            else
            {
                return "PLEASE ENTER A VALID INPUT";
            }
        }

        public string Undo()
        {
            try
            {
                st.Pop();
                pushed = st.Peek();
                return Convert.ToString(pushed);
            }

            catch
            {
                return "UNDO NOT AVAILABLE";
            }
        }

        public string Clear()
        {
            st.Clear();
            pushed = 0;

            return Convert.ToString(pushed);
        }

        public string Exit()
        {
            return "CLOSE PROGRAM";
        }
    }
}
